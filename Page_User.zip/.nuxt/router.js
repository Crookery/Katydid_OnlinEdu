import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _a57c7b22 = () => interopDefault(import('..\\pages\\course\\index.vue' /* webpackChunkName: "pages/course/index" */))
const _06797001 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _2c221d3b = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _63da7f48 = () => interopDefault(import('..\\pages\\teacher\\index.vue' /* webpackChunkName: "pages/teacher/index" */))
const _49eb9497 = () => interopDefault(import('..\\pages\\course\\_id.vue' /* webpackChunkName: "pages/course/_id" */))
const _a55d1c78 = () => interopDefault(import('..\\pages\\order\\_id.vue' /* webpackChunkName: "pages/order/_id" */))
const _6e66e4ac = () => interopDefault(import('..\\pages\\pay\\_id.vue' /* webpackChunkName: "pages/pay/_id" */))
const _0b4e9891 = () => interopDefault(import('..\\pages\\player\\_id.vue' /* webpackChunkName: "pages/player/_id" */))
const _390fb3b0 = () => interopDefault(import('..\\pages\\teacher\\_id.vue' /* webpackChunkName: "pages/teacher/_id" */))
const _3cd1ccea = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/course",
    component: _a57c7b22,
    name: "course"
  }, {
    path: "/login",
    component: _06797001,
    name: "login"
  }, {
    path: "/register",
    component: _2c221d3b,
    name: "register"
  }, {
    path: "/teacher",
    component: _63da7f48,
    name: "teacher"
  }, {
    path: "/course/:id",
    component: _49eb9497,
    name: "course-id"
  }, {
    path: "/order/:id?",
    component: _a55d1c78,
    name: "order-id"
  }, {
    path: "/pay/:id?",
    component: _6e66e4ac,
    name: "pay-id"
  }, {
    path: "/player/:id?",
    component: _0b4e9891,
    name: "player-id"
  }, {
    path: "/teacher/:id",
    component: _390fb3b0,
    name: "teacher-id"
  }, {
    path: "/",
    component: _3cd1ccea,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
